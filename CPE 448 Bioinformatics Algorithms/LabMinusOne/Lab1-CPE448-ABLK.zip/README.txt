Adam Bahceci & Liam Kirsh
CPE 448 Bioinformatics Algorithms
Lab 1-1

General information:
It was not specified how the codon translations should have been loaded, so we used a text file to load them into memory. Hard coding them into the source code would have been just as easy.

Steps for compiling the code:

python <sourcecode name> <testfile name>

example:
python Lab1-1.py tests/test1.txt
